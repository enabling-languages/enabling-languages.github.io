# Padauk

Padauk is a pan Burma font designed to support all Myanmar script based languages.
It covers all of the Unicode Myanmar script blocks and works on all OpenType
and Graphite based systems.

## Project status [![Build Status](http://build.palaso.org/app/rest/builds/buildType:Fonts_Padauk/statusIcon)](http://build.palaso.org/viewType.html?buildTypeId=Fonts_Padauk&guest=1)


Features:
* Special support for: ksw, kht, kyu, shn, aio, phk
* Variation Selector support for kht, aio, phk

Issues:
* Does not work in Word 2007

